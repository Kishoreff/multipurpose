const Utils = require("../modules/utils.js");
const { config, lang, commands } = Utils.variables;
const Embed = Utils.Embed;
const CommandHandler = require('../modules/handlers/CommandHandler');
const eventHandler = require('../modules/handlers/EventHandler');
const CustomConfig = require('../modules/CustomConfig.js');
const utilsPlus = require("../59Utils.js");
const request = require('request-promise')

module.exports = async bot => {
  const addonConfig = new CustomConfig("./addon_configs/RockstarStatus.yml", {
    RequiredRole: "@everyone",
    Embed: {
      Author: 'Rockstar Games • Server Status',
      AuthorIcon: 'https://upload.wikimedia.org/wikipedia/commons/thumb/5/53/Rockstar_Games_Logo.svg/1200px-Rockstar_Games_Logo.svg.png',
      Description: 'Last updated by Rockstar on {update}',
      Fields: [
        {
          name: '🐴 __Red Dead Online__',
          value: '{RedDeadStats}',
          inline: true
        },
        {
          name: '🚓 __GTA Online__',
          value: '{GtaStats}',
          inline: true
        },
        {
          name: '🗨️ __Social Club__',
          value: '{SocialClubStats}',
          inline: true
        },
        {
          name: '🚀 __Rockstar Launcher__',
          value: '{RockstarLauncherStats}',
          inline: true
        },
        {
          name: ':eggplant: __Rockstar Support__',
          value: '{RockstarSupportStats}',
          inline: true
        }
      ]
    },
    LoadingEmbed: {
      Author: 'Loading Rockstar Server Stats.... This could take a few seconds.'
    }
  })
  CommandHandler.set({
    name: 'rockstar',
    run: async (bot, message, args) => {
      if (!Utils.hasPermission(message.member, addonConfig.RequiredRole)) return message.channel.send(Embed({ preset: 'nopermission' }))
      const msg = await message.channel.send(Utils.setupEmbed({
        configPath: addonConfig.LoadingEmbed
      }))
      request('https://support.rockstargames.com/services/status.json').then(res => {
        res = JSON.parse(res)
        const stats = res.statuses
        msg.edit(Utils.setupEmbed({
          configPath: addonConfig.Embed,
          variables: [
            { searchFor: /{RedDeadStats}/g, replaceWith: stats[1].services_platforms.map(s => `${s.service_status.status.toLowerCase() === 'up' ? '🟢' : s.service_status.status.toLowerCase() === 'down' ? '🔴' : '🟡'} ${s.name}`).join('\n') },
            { searchFor: /{GtaStats}/g, replaceWith: stats[2].services_platforms.map(s => `${s.service_status.status.toLowerCase() === 'up' ? '🟢' : s.service_status.status.toLowerCase() === 'down' ? '🔴' : '🟡'} ${s.name}`).join('\n') },
            { searchFor: /{SocialClubStats}/g, replaceWith: stats[3].services_platforms.map(s => `${s.service_status.status.toLowerCase() === 'up' ? '🟢' : s.service_status.status.toLowerCase() === 'down' ? '🔴' : '🟡'} ${s.name}`).join('\n') },
            { searchFor: /{RockstarLauncherStats}/g, replaceWith: stats[5].services_platforms.map(s => `${s.service_status.status.toLowerCase() === 'up' ? '🟢' : s.service_status.status.toLowerCase() === 'down' ? '🔴' : '🟡'} ${s.name}`).join('\n') },
            { searchFor: /{RockstarSupportStats}/g, replaceWith: stats[4].services_platforms.map(s => `${s.service_status.status.toLowerCase() === 'up' ? '🟢' : s.service_status.status.toLowerCase() === 'down' ? '🔴' : '🟡'} ${s.name}`).join('\n') },
            { searchFor: /{update}/g, replaceWith: res.updated },
          ]
        }))
      }).catch(err => {
        message.channel.send('An error occured. check console!')
        console.log(err)
      })
    },
    description: "View stats for rockstar services",
    usage: 'rockstar',
    aliases: [],
    type: 'fun'
  })
}