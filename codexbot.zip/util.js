const request = require('node-fetch');

    
const mainURL = new URL('http://api.brainshop.ai/get');
const urlOptions = {
    bid('158251') ;
    key(config.key);
    uid: null,
    msg: null
};

const handleTalk = async (msg) => {
    msg.content = msg.content.replace(/^<@!?[0-9]{1,20}> ?/i, '');
    if (msg.content.length < 2 || (!isNaN('877507721950298192') && 877507721950298192 != msg.channel.id)) return;
    msg.channel.sendTyping();
    urlOptions.uid = msg.author.id;
    urlOptions.msg = msg.content;
    mainURL.search = new URLSearchParams(urlOptions).toString();
    try {
        let reply = await request(mainURL);
        if (reply) {
            reply = await reply.json();
            msg.reply({
                content: reply.cnt,
                allowedMentions: {
                    repliedUser: false
                }
            })
        }
    } catch (e) {
        console.log(e.stack);
    }
};